package org.SparkWC

import org.apache.spark.SparkConf
import org.apache.spark.SparkContext


object Driver {
  def main(args: Array[String]): Unit = {
    //Set Hadoop home directory
    System.setProperty("hadoop.home.dir", "C:\\Hadoop\\hadoop-common-2.2.0-bin-master\\")
    //Setting up Spark configurations
    val conf = new SparkConf().setAppName("SparkWordCount").setMaster("local")
    val sc = new SparkContext(conf)
    
	//Loading the data file
	val textFile = sc.textFile(args(0))
	val counts = textFile
	.flatMap(line => line.split("\\W+"))
	.filter(!_.isEmpty)
	.map(word => (word, 1))
	.reduceByKey(_ + _) //word count module
	.sortByKey()
	counts.saveAsTextFile(args(1)) //Saving the result in a text file
  
  }
}