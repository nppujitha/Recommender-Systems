package org.SparkML
import org.apache.spark.SparkConf
import org.apache.spark.SparkContext
import org.apache.spark.mllib.tree.DecisionTree
import org.apache.spark.mllib.tree.model.DecisionTreeModel
import org.apache.spark.mllib.util.MLUtils
import org.apache.spark.mllib.linalg.Vectors
import org.apache.spark.mllib.regression.LabeledPoint

object DecisionTreeDriver {
  
  //defining flight schema
  case class Car (buying : String, maint : String, doors : String, persons : String, lug_boot : String, safety : String, carClass : String)
  
  def main(args : Array[String]): Unit = {
    
    System.setProperty("hadoop.home.dir", "C:\\Hadoop\\hadoop-common-2.2.0-bin-master\\")
    
    //Parsing the input data
    def parseData(str:String) : Car = {
      var col = str.split(",")
      
      if(col.length == 7)
        Car(col(0), col(1), col(2), col(3), col(4), col(5), col(6))
      else Car("None", "None", "None", "None", "None", "None", "None")
    }
    
    
    //Setting up Spark configurations
    val conf = new SparkConf().setAppName("SparkDecisionTreeClassificaton").setMaster("local")
    //starting a new spark context
    val sc = new SparkContext(conf)
    
    //loading input car data
    val CarDataRDD = sc.textFile(args(0))
    //parsing the RDD of text file lines to RDD of car classes
    val parsedCarRDD = CarDataRDD.map(parseData).cache()
    //removing rows with target class as none 
    val validCarRDD = parsedCarRDD.filter(col => !col.carClass.equals("None"))
    println(validCarRDD.count())
    
    
    //Transforming non-numeric to numeric
    var buyingMap = validCarRDD.map(car => car.buying).distinct().zipWithIndex().collectAsMap()
    var maintMap = validCarRDD.map(car => car.maint).distinct().zipWithIndex().collectAsMap()
    var doorsMap = validCarRDD.map(car => car.doors).distinct().zipWithIndex().collectAsMap()
    var personsMap = validCarRDD.map(car => car.persons).distinct().zipWithIndex().collectAsMap()
    var lugMap = validCarRDD.map(car => car.lug_boot).distinct().zipWithIndex().collectAsMap()
    var safetyMap = validCarRDD.map(car => car.safety).distinct().zipWithIndex().collectAsMap()
    var classMap = validCarRDD.map(car => car.carClass).distinct().zipWithIndex().collectAsMap()
    
    
    //defining the features array
    val carPrep = validCarRDD.map(car => { 
      val carClass = classMap(car.carClass)
      val buying = buyingMap(car.buying)
      val maint = maintMap(car.maint)
      val doors = doorsMap(car.doors)
      val persons = personsMap(car.persons)
      val lugBoot = lugMap(car.lug_boot)
      val safety = safetyMap(car.safety)
      
      Array(carClass.toDouble,buying.toDouble,maint.toDouble,doors.toDouble,persons.toDouble,lugBoot.toDouble,safety.toDouble)
    })
    
    
    //Making label points for features
    val carDataLabels = carPrep.map(x => LabeledPoint(x(0), Vectors.dense(x(1), x(2), x(3), x(4), x(5), x(6))))
   

    //splitting the data into train and test sets
    //train set: 70% and test set: 30%
    val splits = carDataLabels.randomSplit(Array(0.7, 0.3))
    val (trainingData, testData) = (splits(0), splits(1))
    

    //setting parameters required for the decision tree model
    val numClasses = 4 //number of car classes is 4
    val categoricalFeaturesInfo = Map[Int, Int]() //no categorical features
    val impurity = "entropy" //decision tree split criteria
    val maxDepth = 5
    val maxBins = 32
    
    //calling decision tree classifier model on the training data
    val model = DecisionTree.trainClassifier(trainingData, numClasses, categoricalFeaturesInfo, impurity, maxDepth, maxBins)
    
    // Evaluating the model on test data and computing the Evaluate model on test instances and compute test error
    val labelAndPreds = testData.map { point =>
      val prediction = model.predict(point.features)
      (point.label, prediction)
    }
    val testErrRate = labelAndPreds.filter(r => r._1 != r._2).count().toDouble / testData.count()
    
   
    println("Misclassification Rate on test data = " + testErrRate)
    println("Accuracy=" + (1-testErrRate))
    println("Splitting criteria Used=" + impurity.toUpperCase())
    println("Target Classes=" + numClasses)
    println("Learned classification tree model:\n" + model.toDebugString)
    
    
  }
}